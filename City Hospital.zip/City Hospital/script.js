// Highlight current nav link
(function() {
    const links = document.querySelectorAll('.main-nav a');
    const path = location.pathname.split('/').pop() || 'index.html';
    links.forEach(a => {
        if (a.getAttribute('href') === path) a.classList.add('active');
    });
})();

// Appointment form handling
(function() {
        const form = document.getElementById('appointmentForm');
        if (!form) return;

        form.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const data = new FormData(form);
                    const name = data.get('name');
                    const email = data.get('email');
                    const phone = data.get('phone');
                    const department = data.get('department');
                    const date = data.get('date');
                    const time = data.get('time');
                    const notes = data.get('notes');

                    const apptId = 'AP' + Date.now().toString().slice(-6);
                    const result = document.getElementById('appointmentResult');
                    const formattedDate = new Date(date + 'T' + time);
                    const dateStr = formattedDate.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
                    const timeStr = formattedDate.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });

                    result.innerHTML = `
            <h3>Appointment Confirmed</h3>
            <p><strong>ID:</strong> ${apptId}</p>
            <p><strong>Name:</strong> ${escapeHtml(name)}</p>
            <p><strong>Department:</strong> ${escapeHtml(capitalize(department))}</p>
            <p><strong>Date & Time:</strong> ${dateStr} at ${timeStr}</p>
            ${notes ? `<p><strong>Notes:</strong> ${escapeHtml(notes)}</p>` : ''}
            <p>Confirmation sent to <strong>${escapeHtml(email)}</strong>.</p>
        `;
        result.hidden = false;
        form.reset();
        result.scrollIntoView({behavior:'smooth'});
    });

    function capitalize(s){ return s ? s.charAt(0).toUpperCase() + s.slice(1) : ''; }
    function escapeHtml(unsafe){ return unsafe ? unsafe.replace(/[&<\"'>]/g, function(m){ return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',\"'\":\"&#039;\"}[m]; }) : ''; }
})();